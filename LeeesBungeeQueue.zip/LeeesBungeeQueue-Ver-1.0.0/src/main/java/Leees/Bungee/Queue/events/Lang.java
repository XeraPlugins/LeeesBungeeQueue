package Leees.Bungee.Queue.events;

/**
 * Lang
 */
public class Lang {

    public static String SEND_TO_LIMBO, CURRENT_LIMBO_POSITION, LEFT_LIMBO_JOIN_SERVER, QUEUE_OVERRIDE_PERMISSION,
            GLOBAL_SLOTS_PERMISSION;
    public static int GLOBAL_SLOTS, SUPER_SLOTS;
}
