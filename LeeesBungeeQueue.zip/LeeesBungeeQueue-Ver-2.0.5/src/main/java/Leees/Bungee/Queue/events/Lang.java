package Leees.Bungee.Queue.events;

/**
 * Lang
 */
public class Lang {

    public static String SERVERISFULLMESSAGE, QUEUEPOSITION, JOININGMAINSERVER, QUEUEBYPASSPERMISSION,
            HEADER, FOOTER, POSITIONMESSAGEHOTBAR, QUEUESERVER;
    public static int MAINSERVERSLOTS, QUEUESERVERSLOTS;
}
